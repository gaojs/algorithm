#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	double a;
	scanf("%lf",&a);
	printf("%.12f",a);
	return 0;
}
