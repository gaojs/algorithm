#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	printf("%8d %8d %8d",a,b,c);
	return 0;
}
