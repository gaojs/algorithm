#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int n;
	cin >> n;
	if( n % 2 )
		cout << "odd" ;
	else
		cout << "even";
	return 0;
}
