#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	char c;
	scanf("%c",&c);
	printf("%d",c);
	return 0;
}
