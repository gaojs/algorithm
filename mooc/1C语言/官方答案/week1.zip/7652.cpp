#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	int a;
	short b;
	printf("%d %d",sizeof(a),sizeof(b));
	return 0;
}
