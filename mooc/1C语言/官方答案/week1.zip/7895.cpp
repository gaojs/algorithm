#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	char c;
	cin >> c;
	cout << "  " << c  << endl;
	cout << " " << c << c << c <<  endl;
	cout << c << c << c << c << c <<  endl;
	cout << " " << c << c << c << endl;
	cout << "  " << c  << endl;
	return 0;
}
