#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	float a;
	double b;
	printf("%d %d",sizeof(a),sizeof(b));
	return 0;
}
