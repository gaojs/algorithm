
#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	 int x ,y ,z;
	 scanf("%d%d%d",&x,&y,&z);
	 printf("%d",y);
	 return 0;
}

��

#include <iostream>
using namespace std;
int main()
{
	 int x ,y ,z;
	 cin >> x >> y >> z;
	 cout << y;
	 return 0;
}